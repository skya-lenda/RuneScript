# Como subir na Vercel — Passo a passo

## 1. Estrutura de arquivos no seu repositório

Copie tudo assim:

```
seu-repo/
├── index-seguro.html       ← renomeie para index.html
├── package.json
├── vercel.json
└── api/
    ├── _lib.js
    ├── auth/
    │   ├── login.js
    │   ├── verify-pin.js
    │   └── set-pin.js
    ├── user/
    │   └── me.js
    ├── modulos/
    │   ├── cep.js
    │   ├── cnpj.js
    │   ├── ip.js
    │   ├── dominio.js
    │   ├── site.js
    │   ├── username.js
    │   └── termo.js
    └── admin/
        ├── users.js
        ├── users/
        │   └── [id].js
        ├── logs.js
        └── stats.js
```

## 2. Variáveis de ambiente na Vercel

Acesse: vercel.com → seu projeto → Settings → Environment Variables

Adicione uma por uma:

| Nome | Valor |
|------|-------|
| `SUPABASE_URL` | `https://xxxx.supabase.co` |
| `SUPABASE_SERVICE_KEY` | A **service_role** key (não a anon!) — Supabase → Settings → API |
| `JWT_SECRET` | Qualquer string longa aleatória. Ex: `minha_chave_super_secreta_2026_xyzabc` |
| `ADMIN_USERNAME` | Seu username de admin. Ex: `dafyganggov` |
| `ADMIN_PASSWORD_HASH` | Veja passo 3 abaixo |
| `ANTHROPIC_API_KEY` | Sua chave da Anthropic |

## 3. Gerar o hash bcrypt da senha do admin

Acesse: https://bcrypt.online

- Digite sua senha
- Cost factor: 12
- Clique em "Hash"
- Cole o resultado no campo `ADMIN_PASSWORD_HASH`

## 4. Fazer deploy

Suba os arquivos no GitHub e a Vercel vai fazer o deploy automático.

## 5. Testar

Acesse seu site, faça login com usuário + senha do admin.

---

## Problemas comuns

**"Não autenticado" em tudo** → JWT_SECRET está errado ou vazio na Vercel

**"Erro interno" no login** → SUPABASE_SERVICE_KEY errada (confirme que é a service_role, não a anon)

**Admin não loga** → ADMIN_PASSWORD_HASH não foi gerado corretamente. Refaça o passo 3.
